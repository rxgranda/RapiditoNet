Para ejecutar el proyecto, debemos seguir los siguentes pasos.

////////////////////////////////////////////////////////////////////////////////////////////////

Apartheid (Aplcación Servidor)


Compilación:

	gcc -o Main main.c vector.c -pthread


Ejecución:

	En una consola de comandos:

	./Main -N 3


	Donde el parámetro N indica el número N de hilos que sirve de referencia para los planes de Rapiditonet.

///////////////////////////////////////////////////////////////////////////////////////////////


Gentram (Aplicación Cliente)

	Ejecución:

		En una nueva consola de comandos ejecutar:

		./gentram
